# BOSS AI standalone Android build bundle

This archive is only for the **BOSS_AI** project. It is not BOSS_DEV_ENGINE.

## GitHub upload layout
Upload/extract the contents of this ZIP into the root of the BOSS_AI repository so the repository root contains:
- `android-standalone/`
- `.github/workflows/build-android-apk.yml`

Do not keep an extra outer `BOSS_AI/` folder around these paths, or the workflow working-directory will not be found.

## Run build
1. Push/commit these files to the BOSS_AI repository.
2. Open the repository's **Actions** tab.
3. Choose **Build BOSS AI Android APK** and press **Run workflow**. Alternatively, a push affecting the listed paths starts it automatically.
4. Open the completed run and download artifact `boss-ai-standalone-debug-apk`.

## Scope warning
This produces a debug APK for the current standalone shell. It is an offline chat UI prototype; the bundled status document says real AI responses/backend are not connected. A successful APK build is not proof that the full BOSS_AI migration is complete.
