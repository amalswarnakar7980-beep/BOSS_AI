plugins { id("com.android.application") }

android {
    namespace = "ai.boss.standalone"
    compileSdk = 35
    defaultConfig { applicationId = "ai.boss.standalone"; minSdk = 23; targetSdk = 35; versionCode = 2; versionName = "0.2.0" }
}
