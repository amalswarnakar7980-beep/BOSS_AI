# BOSS AI Standalone Android

Open this directory in Android Studio. See `BUILD_AND_STATUS.md` for build instructions, current limits, and mandatory verification gates.
