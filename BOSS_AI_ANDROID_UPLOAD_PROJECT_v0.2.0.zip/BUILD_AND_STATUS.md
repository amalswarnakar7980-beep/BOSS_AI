# BOSS AI Standalone Android source bundle v0.2.0

## Goal
Native Android application shell; end-user runtime does not require Python or Termux. The app embeds local HTML/CSS/JS in Android WebView and stores chat history using localStorage.

## Build
Open this `android-standalone` directory in Android Studio with Android SDK Platform 35 installed. Allow Gradle to resolve the Android Gradle Plugin, then select **Build > Build APK(s)**. Debug APK is normally produced at `app/build/outputs/apk/debug/app-debug.apk`. This bundle does not include a compiled APK, Android SDK, Gradle wrapper binary, signing keys, or an AI provider.

## Current scope
- Standalone Android launcher activity
- Offline chat interface and local history
- No Python/Termux runtime dependency
- No INTERNET permission
- No real AI responses; prototype explicitly marks backend as not connected

## Required next gates
1. Build on Android SDK toolchain and install on target phone.
2. Verify Android 6+ launch, back navigation, rotation/relaunch persistence, clear-history behavior, and storage limits.
3. Port the BOSS API routes from `migration/python-free/route-contract.json` one by one with parity/security tests.
4. Integrate local/remote AI only with explicit provider/security design.
5. Run regression, rollback drill, and sealed-hash recheck.
6. Do not replace legacy `main.py` or claim full migration until all gates pass.

## Important
The bundled Node migration runtime is for development/testing only; it is not packaged inside this APK. This Android shell does not require the user to install Termux or Python.
