#!/system/bin/sh
set -eu
[ -f settings.gradle.kts ]
[ -f build.gradle.kts ]
[ -f app/build.gradle.kts ]
[ -f app/src/main/AndroidManifest.xml ]
[ -d app/src/main ]
echo 'SOURCE STRUCTURE PASS (not an APK build/runtime test)'
