BOSS AI Android standalone source project v0.2.0

This ZIP contains the Android Gradle project at the archive root.
Upload this ZIP to an Android builder that accepts source Android Gradle projects.

Important: this is source code, not a compiled APK. A successful APK build has not been verified here. The project does not include a Gradle wrapper, Android SDK, or signing key. The current app is an offline prototype; a real AI engine/backend is not connected.
